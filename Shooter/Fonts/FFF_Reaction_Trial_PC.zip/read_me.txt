You may use these fonts for personal and non commercial use only. These fonts may be freely redistributed, provided that you do not alter them in any way and that you credit Fonts For Flash for this.

These fonts are distributed free and may not be sold or resold for any purposes.

Fonts For Flash does not take any responsibility for any damage caused through use of these fonts, be it indirect, special, incidental or consequential damages (including damages for loss of business, loss of profits, interruption or the like).

To use these fonts, place the text on exact X and Y integers (whole numbers). The fonts size must be set at 8 pixels only. Do not use bold or italic settings. When publishing, ensure that you set to publish at pixels or "match movie" only.

Only letters from A-Z are provided with this free trial version. The full version may be purchased from www.fontsforflash.com (includes full user guide).


Thank you. The FFF Team